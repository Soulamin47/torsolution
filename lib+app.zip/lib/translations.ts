export const translations = {
  en: {
    // Navbar / global
    tagline: "Digital product design & delivery",
    navSystems: "Projects",
    navCapabilities: "What I do",
    navProcess: "How I work",
    navContact: "Contact",

    // Hero
    heroBadge: "Product Engineering | Digital Systems",
    heroTitle: "I build digital products that are fast, reliable, and ready to grow.",
    heroSubtitle:
      "Web apps, mobile apps, and digital platforms designed to be easy to use, strong over time, and able to scale with your business.",
    viewSystems: "View projects",
    startProject: "Start a conversation",
    scroll: "Discover",
    heroPoints: [
      "Fast, structured delivery (weeks, not months)",
      "Reliable and maintainable — built to last",
      "Ready for growth: performance, security, scalability",
    ],
    availability: "Available for missions and partnerships — Brussels / Remote",

    // Capabilities
    capTitle: "What I can deliver",
    capSubtitle:
      "From idea to launch: end-to-end product delivery with a focus on clarity, performance, and long-term maintainability.",
    capItems: [
      {
        title: "Web & mobile applications",
        desc: "Modern, polished experiences that load fast and feel great on every device.",
        tag: "Web / Mobile",
        icon: "</>",
      },
      {
        title: "Business platforms",
        desc: "Dashboards, admin tools and internal platforms to run and measure your operations.",
        tag: "Platforms",
        icon: "DB",
      },
      {
        title: "Launch & reliability",
        desc: "Deployment, monitoring and a clean structure so your product stays stable as it grows.",
        tag: "Delivery",
        icon: "☁",
      },
      {
        title: "Automation & AI",
        desc: "Smart workflows that save time and improve service quality (when it makes sense).",
        tag: "Automation",
        icon: "AI",
      },
      {
        title: "Web3 (optional)",
        desc: "If needed: blockchain integration and smart contracts for specific product use-cases.",
        tag: "Web3",
        icon: "◇",
      },
    ],

    // Systems
    sysTitle: "Selected projects",
    sysSubtitle:
      "A few examples of products and platforms I design and build.",
    exploreSystem: "Discuss a similar project",
    sysObjectiveLabel: "Objective",
    sysOutcomeLabel: "Result",
    sysItems: [
      {
        number: "01",
        title: "Analytics & reporting platform",
        desc: "A real-time dashboard that helps teams track key metrics, make decisions faster, and stay aligned.",
        objective: "Give teams clear visibility on key metrics and performance.",
        outcome: "Faster decision-making and better alignment across stakeholders.",
        tags: ["Dashboard", "B2B", "Data"],
        image: "/system-1.jpg",
      },
      {
        number: "02",
        title: "Assistant & automation system",
        desc: "A conversational assistant designed to guide users, answer questions and automate recurring tasks.",
        objective: "Reduce repetitive workload and improve user support.",
        outcome: "Less manual work, quicker answers, and smoother operations.",
        tags: ["Assistant", "Automation", "Knowledge"],
        image: "/system-2.jpg",
      },
    ],

    // Process
    procTitle: "How I work",
    procSubtitle:
      "A simple, structured approach to turn an idea into a real product.",
    procSteps: [
      {
        n: "01",
        title: "Understand the goal",
        desc: "Clarify objectives, users, and constraints so we build the right thing.",
        icon: "💡",
      },
      {
        n: "02",
        title: "Design the solution",
        desc: "Define the product structure and key flows, with a plan that fits your timeline.",
        icon: "⚡",
      },
      {
        n: "03",
        title: "Build & test",
        desc: "Develop with quality checks so the product is stable, fast and easy to maintain.",
        icon: "🧱",
      },
      {
        n: "04",
        title: "Launch & improve",
        desc: "Ship, monitor, and iterate based on real feedback and usage.",
        icon: "📈",
      },
    ],

    // CTA
    ctaTitle: "Let's build something solid.",
    ctaSubtitle:
      "If you have a digital idea or a product to improve, let's talk.",
    ctaButton: "Send a message",
    ctaCall: "Request a 15‑min call",
    ctaBrief: "Send a brief",
    ctaResponse: "Response within 24 business hours.",

    // Contact form
    contactName: "Name",
    contactEmail: "Email",
    contactSubject: "Subject (optional)",
    contactMessage: "Tell me about your project...",
    contactSend: "Send message",

    // Footer
    footerTagline: "Premium delivery — clear, reliable, and built to last.",
  },

  fr: {
    // Navbar / global
    tagline: "Conception de produits numériques performants",
    navSystems: "Projets",
    navCapabilities: "Ce que je fais",
    navProcess: "Méthode",
    navContact: "Contact",

    // Hero
    heroBadge: "Product Engineering | Digital Systems",
    heroTitle: "Je conçois des produits numériques rapides, fiables et prêts à évoluer.",
    heroSubtitle:
      "Applications web, mobile et plateformes digitales conçues pour être simples à utiliser, solides dans le temps et capables de grandir avec votre projet.",
    viewSystems: "Voir les projets",
    startProject: "Parlons de votre projet",
    scroll: "Découvrir",
    heroPoints: [
      "Livraison rapide et cadrée (en semaines, pas en mois)",
      "Fiable et maintenable — pensé pour durer",
      "Prêt pour la croissance : performance, sécurité, évolution",
    ],
    availability: "Disponible pour missions et partenariats — Bruxelles / Remote",

    // Capabilities
    capTitle: "Ce que je peux construire",
    capSubtitle:
      "De l’idée au produit final : je conçois et développe des solutions numériques complètes, pensées pour être performantes et durables.",
    capItems: [
      {
        title: "Applications web & mobile",
        desc: "Des interfaces modernes et soignées, rapides et agréables sur tous les appareils.",
        tag: "Web / Mobile",
        icon: "</>",
      },
      {
        title: "Plateformes métier",
        desc: "Dashboards, back-offices et outils internes pour piloter l’activité et gagner en efficacité.",
        tag: "Plateformes",
        icon: "DB",
      },
      {
        title: "Mise en ligne & fiabilité",
        desc: "Déploiement, suivi et structure propre pour un produit stable qui tient dans le temps.",
        tag: "Livraison",
        icon: "☁",
      },
      {
        title: "Automatisation & IA",
        desc: "Des automatisations utiles pour gagner du temps et améliorer la qualité de service.",
        tag: "Automatisation",
        icon: "IA",
      },
      {
        title: "Web3 (si nécessaire)",
        desc: "Intégration blockchain et smart contracts lorsque c’est pertinent pour le produit.",
        tag: "Web3",
        icon: "◇",
      },
    ],

    // Systems
    sysTitle: "Projets & systèmes",
    sysSubtitle:
      "Quelques exemples de plateformes et produits numériques que je conçois et développe.",
    exploreSystem: "Discuter d’un projet similaire",
    sysObjectiveLabel: "Objectif",
    sysOutcomeLabel: "Résultat",
    sysItems: [
      {
        number: "01",
        title: "Plateforme d’analytics & reporting",
        desc: "Un tableau de bord en temps réel pour suivre les indicateurs clés et prendre de meilleures décisions.",
        objective: "Donner une visibilité claire sur les indicateurs clés.",
        outcome: "Décisions plus rapides et meilleure coordination.",
        tags: ["Dashboard", "B2B", "Données"],
        image: "/system-1.jpg",
      },
      {
        number: "02",
        title: "Assistant & système d’automatisation",
        desc: "Un assistant conversationnel pour guider les utilisateurs, répondre aux questions et automatiser des tâches récurrentes.",
        objective: "Réduire le travail répétitif et améliorer le support.",
        outcome: "Moins de tâches manuelles, réponses plus rapides, opérations plus fluides.",
        tags: ["Assistant", "Automatisation", "Connaissance"],
        image: "/system-2.jpg",
      },
    ],

    // Process
    procTitle: "Méthode de travail",
    procSubtitle:
      "Une approche simple et structurée pour transformer une idée en produit réel.",
    procSteps: [
      {
        n: "01",
        title: "Comprendre le besoin",
        desc: "Clarifier vos objectifs, vos utilisateurs et les contraintes pour partir sur de bonnes bases.",
        icon: "💡",
      },
      {
        n: "02",
        title: "Concevoir la solution",
        desc: "Définir la structure du produit et les parcours clés, avec un plan adapté au timing.",
        icon: "⚡",
      },
      {
        n: "03",
        title: "Développer & tester",
        desc: "Construire avec des contrôles qualité pour un produit stable, rapide et maintenable.",
        icon: "🧱",
      },
      {
        n: "04",
        title: "Lancer & améliorer",
        desc: "Mise en ligne, suivi, puis améliorations basées sur les retours et l’usage réel.",
        icon: "📈",
      },
    ],

    // CTA
    ctaTitle: "Construisons quelque chose de solide.",
    ctaSubtitle:
      "Si vous avez une idée ou un projet digital, discutons-en.",
    ctaButton: "Envoyer un message",
    ctaCall: "Demander un appel de 15 min",
    ctaBrief: "Envoyer un brief",
    ctaResponse: "Réponse sous 24h ouvrées.",

    // Contact form
    contactName: "Nom",
    contactEmail: "Email",
    contactSubject: "Sujet (optionnel)",
    contactMessage: "Parlez-moi de votre projet...",
    contactSend: "Envoyer",

    // Footer
    footerTagline: "Des produits premium, clairs, fiables - et faits pour durer.",
  },
};