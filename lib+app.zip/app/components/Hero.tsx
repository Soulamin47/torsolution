"use client";

import { motion } from "framer-motion";
import { useLang } from "@/app/providers/LangProvider";
import { translations } from "@/lib/translations";

export default function Hero() {
  const { lang } = useLang();
  const t = translations[lang] as any;

  return (
    <section className="px-8 pt-10 pb-20">
      <div className="mx-auto max-w-6xl">
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 px-8 py-16">
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-blue-500/10 via-transparent to-indigo-500/10" />

          <div className="relative">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55 }}
              className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/30 px-4 py-2 text-xs text-gray-200"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
              {t.heroBadge}
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.05 }}
              className="mt-6 text-4xl font-semibold tracking-tight sm:text-5xl"
            >
              {t.heroTitle}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.1 }}
              className="mt-5 max-w-2xl text-base leading-relaxed text-gray-300"
            >
              {t.heroSubtitle}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.15 }}
              className="mt-8 flex flex-col gap-3 sm:flex-row"
            >
              <a
                href="#contact"
                className="inline-flex items-center justify-center rounded-xl bg-white px-6 py-3 text-sm font-medium text-black transition hover:bg-white/90"
              >
                {t.startProject}
              </a>
              <a
                href="#systems"
                className="inline-flex items-center justify-center rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-medium text-white transition hover:bg-white/10"
              >
                {t.viewSystems}
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.2 }}
              className="mt-10 grid gap-3 sm:grid-cols-3"
            >
              {(t.heroPoints || []).map((p: string) => (
                <div
                  key={p}
                  className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-gray-200"
                >
                  {p}
                </div>
              ))}
            </motion.div>

            {t.availability ? (
              <div className="mt-6 text-sm text-gray-300/90">
                {t.availability}
              </div>
            ) : null}

            {t.scroll ? (
              <div className="mt-10 inline-flex items-center gap-2 text-xs text-gray-400">
                <span className="opacity-70">{t.scroll}</span>
                <span className="opacity-40">↓</span>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
